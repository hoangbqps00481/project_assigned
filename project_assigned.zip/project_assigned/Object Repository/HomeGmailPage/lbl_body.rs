<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_body</name>
   <tag></tag>
   <elementGuidId>e2a7c607-0e95-4520-b0d8-d26a379d2c33</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@dir='ltr' and contains(text(),'[Percel Perform] Interview invitation for Automation QA/QC Engineer.')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
