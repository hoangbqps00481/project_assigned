<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Email or phone.</description>
   <name>txt_UserName</name>
   <tag></tag>
   <elementGuidId>2914b3b2-8aa9-4605-b9cb-235c52c49b20</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div/input[@type='email']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
